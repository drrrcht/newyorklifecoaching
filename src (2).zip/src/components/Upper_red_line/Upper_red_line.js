import React from "react";
import "./css/Upper_red_line.css"
export default function Upper_red_line() {
    return (
        <div className="upper_red_line">
            <p>START YOUR JOURNEY TO BECOME A LIFE COACH NOW.<span>CLICK HERE TO LEARN MORE.</span></p>
        </div>
    );
}