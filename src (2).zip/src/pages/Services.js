import React from "react";

export const Services = () => {
    return(
        <h2>Services page</h2>
    );
}