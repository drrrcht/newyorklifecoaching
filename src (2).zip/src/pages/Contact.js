import React from "react";

export const Contact = () => {
    return(
        <h2>Contact page</h2>
    );
}