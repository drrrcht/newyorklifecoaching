import React from "react";

export const About = () => {
    return(
        <h2>About page</h2>
    );
}