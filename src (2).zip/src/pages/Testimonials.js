import React from "react";

export const Testimonials = () => {
    return(
        <h2>Testimonials page</h2>
    );
}