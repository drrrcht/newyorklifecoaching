import React from "react";

export const Blog = () => {
    return(
        <h2>Blog page</h2>
    );
}