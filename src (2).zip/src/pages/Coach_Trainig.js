import React from "react";

export const Coach_Trainig = () => {
    return(
        <h2>Coach_Trainig page</h2>
    );
}